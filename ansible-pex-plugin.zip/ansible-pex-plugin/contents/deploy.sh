#!/bin/bash

ANSIBLE_USER=$1
PEX_SOURCE_URL=$2
WORKDIR=$3
PLAYBOOK=$4
INVENTORY_FILE=$5
EXTRA_VARS=$6
BECOME=$7
PEX_BINARY=$(basename $PEX_SOURCE_URL)

cd $WORKDIR
curl -fLOsS $PEX_SOURCE_URL && echo "PEX downloaded successfully"
chmod +x $PEX_BINARY
PEX_SCRIPT=ansible ./$PEX_BINARY --version

mkdir -p "$WORKDIR/temp"
SSH_KEY_STORAGE_PATH=$(mktemp "$WORKDIR/temp/ssh-keyfile.XXXXX")
EXTRA_VARS_PATH=$(mktemp "$WORKDIR/temp/extra_vars.XXXXX")
echo "$RD_CONFIG_SSH_KEY_STORAGE_PATH" > $SSH_KEY_STORAGE_PATH
echo "$EXTRA_VARS" | tr ',' '\n' > $EXTRA_VARS_PATH
sed -i 's/^ *//' $EXTRA_VARS_PATH
trap "rm -rf $WORKDIR/temp" EXIT

if [[ $BECOME == true ]]; then
PEX_SCRIPT=ansible-playbook ./$PEX_BINARY $PLAYBOOK \
    --user=$ANSIBLE_USER \
    --private-key=$SSH_KEY_STORAGE_PATH \
    --ssh-extra-args='-o StrictHostKeyChecking=no' \
    --inventory=$INVENTORY_FILE \
    --limit=$RD_OPTION_HOSTNAME \
    --extra-vars=@$EXTRA_VARS_PATH \
    --become
else
PEX_SCRIPT=ansible-playbook ./$PEX_BINARY $PLAYBOOK \
    --user=$ANSIBLE_USER \
    --private-key=$SSH_KEY_STORAGE_PATH \
    --ssh-extra-args='-o StrictHostKeyChecking=no' \
    --inventory=$INVENTORY_FILE \
    --limit=$RD_OPTION_HOSTNAME \
    --extra-vars=@$EXTRA_VARS_PATH
fi

if [[ $? -eq 0 ]]; then
    exit 0
else
    exit 1
fi