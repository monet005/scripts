#!/bin/bash

ANSIBLE_USER=$1
PEX_SOURCE_URL=$2
WORKDIR=$3
PLAYBOOK=$4
INVENTORY_FILE=$5
EXTRA_VARS=$6
BECOME=$7
PEX_BINARY=$(basename $PEX_SOURCE_URL)
TMPDIR=$RD_PLUGIN_TMPDIR/pextmp
PEX_CACHE=$WORKDIR/.pex

if [[ -z $(echo $RD_OPTION_HOSTNAME) ]]; then
    echo "NO target hosts specified"; exit 1
fi

cd $WORKDIR
curl -fLOsS $PEX_SOURCE_URL && echo "PEX downloaded successfully"
chmod +x $PEX_BINARY
PEX_ROOT=${PEX_CACHE} PEX_SCRIPT=ansible ./$PEX_BINARY --version

mkdir -p "$TMPDIR"
SSH_KEY_STORAGE_PATH=$(mktemp "$TMPDIR/ssh-keyfile.XXXXX")
EXTRA_VARS_PATH=$(mktemp "$TMPDIR/extra_vars.XXXXX")
echo "$RD_CONFIG_SSH_KEY_STORAGE_PATH" > $SSH_KEY_STORAGE_PATH
echo "$EXTRA_VARS" | tr ',' '\n' > $EXTRA_VARS_PATH
sed -i 's/^ *//' $EXTRA_VARS_PATH
trap "rm -rf $TMPDIR" EXIT

if [[ $BECOME == true ]]; then
PEX_ROOT=${PEX_CACHE} PEX_SCRIPT=ansible-playbook ./$PEX_BINARY $PLAYBOOK \
    --user=$ANSIBLE_USER \
    --private-key=$SSH_KEY_STORAGE_PATH \
    --ssh-extra-args='-o StrictHostKeyChecking=no' \
    --inventory=$INVENTORY_FILE \
    --limit=$RD_OPTION_HOSTNAME \
    --extra-vars=@$EXTRA_VARS_PATH \
    --become
else
PEX_ROOT=${PEX_CACHE} PEX_SCRIPT=ansible-playbook ./$PEX_BINARY $PLAYBOOK \
    --user=$ANSIBLE_USER \
    --private-key=$SSH_KEY_STORAGE_PATH \
    --ssh-extra-args='-o StrictHostKeyChecking=no' \
    --inventory=$INVENTORY_FILE \
    --limit=$RD_OPTION_HOSTNAME \
    --extra-vars=@$EXTRA_VARS_PATH
fi

if [[ $? -eq 0 ]]; then
    exit 0
else
    exit 1
fi